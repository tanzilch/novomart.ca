<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<?php echo $__env->make('include.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="app sidebar-mini ltr light-mode">
	<div class="page">
		<div class="page-main">
		<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		

		<div class="main-content app-content m-0 mt-0">
                <div class="side-app">
				<?php echo $__env->yieldContent('content'); ?>
			</div>
		</div>

		</div>
		<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
	<?php echo $__env->make('include.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->yieldContent('customJs'); ?>
</body>
</html><?php /**PATH E:\xampp\htdocs\novomart.ca\resources\views/layouts/main.blade.php ENDPATH**/ ?>