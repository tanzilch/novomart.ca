<!-- app-Header -->
<div class="app-header header sticky p-1">
    <div class="container-fluid main-container">
        <div class="container p-0">
                <div class="float-left d-flex w-100 justify-content-between">
                        
                        <!-- sidebar-toggle-->
                        <a href="#" class="text-center">
                            <img src="<?php echo e(asset('assets/site_asset/images/brand/CA-logo-brb.png')); ?>" width="90" height="90" class="header-brand-img desktop-logo " alt="logo">                  
                        </a>
                        <div>
                <?php if(!(Auth::user())): ?>
                <div>
                    <p class="h1 mb-2 cstm-fontSize text-center" style="font-size: 80px">Place Your Order</p>
                </div>
                <?php endif; ?>
                </div>
                <?php if(Auth::user()): ?>
                <div>
                    <a class="dropdown-item font-weight-bold" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <?php else: ?>
                <div>
                    <a href="<?php echo e(route('login')); ?>" class="dropdown-item font-weight-bold" href="<?php echo e(route('logout')); ?>">
                        Login
                    </a>
                </div>
                <?php endif; ?>
                        
                        <!-- LOGO -->
                        
                </div>
        </div>
    </div>      
</div>
<!-- /app-Header --><?php /**PATH E:\xampp\htdocs\novomart.ca\resources\views/include/header.blade.php ENDPATH**/ ?>