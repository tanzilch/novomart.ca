<script src="<?php echo e(asset('public/assets/js/plugins/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/plugins/bootstrap.min.js')); ?>"></script>
<!-- JQUERY JS -->
<script src="<?php echo e(asset('public/assets/site_asset/js/jquery.min.js')); ?>"></script>

<!-- BOOTSTRAP JS -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- SPARKLINE JS-->
<script src="<?php echo e(asset('public/assets/site_asset/js/jquery.sparkline.min.js')); ?>"></script>

<!-- Sticky js -->
<script src="<?php echo e(asset('public/assets/site_asset/js/sticky.js')); ?>"></script>

<!-- CHART-CIRCLE JS-->
<script src="<?php echo e(asset('public/assets/site_asset/js/circle-progress.min.js')); ?>"></script>

<!-- PIETY CHART JS-->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/peitychart/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/peitychart/peitychart.init.js')); ?>"></script>

<!-- SIDEBAR JS -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/sidebar/sidebar.js')); ?>"></script>

<!-- Perfect SCROLLBAR JS-->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/p-scroll/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/p-scroll/pscroll.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/p-scroll/pscroll-1.js')); ?>"></script>

<!-- INTERNAL CHARTJS CHART JS-->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/chart/Chart.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/chart/rounded-barchart.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/chart/utils.js')); ?>"></script>

<!-- INTERNAL SELECT2 JS -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/select2/select2.full.min.js')); ?>"></script>

<!-- INTERNAL Data tables js-->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>

<!-- INTERNAL APEXCHART JS -->
<script src="<?php echo e(asset('public/assets/site_asset/js/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/apexchart/irregular-data-series.js')); ?>"></script>

<!-- C3 CHART JS -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/charts-c3/d3.v5.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/charts-c3/c3-chart.js')); ?>"></script>

<!-- CHART-DONUT JS -->
<script src="<?php echo e(asset('public/assets/site_asset/js/charts.js')); ?>"></script>

<!-- INTERNAL Flot JS -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/flot/jquery.flot.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/flot/jquery.flot.fillbetween.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/flot/chart.flot.sampledata.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/flot/dashboard.sampledata.js')); ?>"></script>

<!-- INTERNAL Vector js -->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/site_asset/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>

<!-- SIDE-MENU JS-->
<script src="<?php echo e(asset('public/assets/site_asset/plugins/sidemenu/sidemenu.js')); ?>"></script>

<!-- INTERNAL INDEX JS -->
<script src="<?php echo e(asset('public/assets/site_asset/js/index1.js')); ?>"></script>

<!-- Color Theme js -->
<script src="<?php echo e(asset('public/assets/site_asset/js/themeColors.js')); ?>"></script>

<!-- CUSTOM JS -->
<script src="<?php echo e(asset('public/assets/site_asset/js/custom.js')); ?>"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script><?php /**PATH E:\xampp\htdocs\novomart.ca\resources\views/include/scripts.blade.php ENDPATH**/ ?>