<!-- FOOTER -->
<footer class="footer p-2">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © 2022 <a href="#">novomart.ca</a>. All rights reserved.
            </div>
        </div>
    </div>
</footer>
<!-- FOOTER END --><?php /**PATH E:\xampp\htdocs\novomart.ca\resources\views/include/footer.blade.php ENDPATH**/ ?>