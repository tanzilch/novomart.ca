<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/css/plugins/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- FAVICON -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/assets/site_asset/images/brand/favicon.ico')); ?>" />

<!-- BOOTSTRAP CSS -->
<link id="style" href="<?php echo e(asset('public/assets/site_asset/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="<?php echo e(asset('public/assets/site_asset/css/style.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('public/assets/site_asset/css/dark-style.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('public/assets/site_asset/css/transparent-style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/site_asset/css/skin-modes.css')); ?>" rel="stylesheet" />

<!--- FONT-ICONS CSS -->
<link href="<?php echo e(asset('public/assets/site_asset/css/icons.css')); ?>" rel="stylesheet" />

<!-- COLOR SKIN CSS -->
<link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('public/assets/site_asset/colors/color1.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/assets/css/style.css')); ?>" />

<script src="https://code.jquery.com/jquery-3.3.1.min.js"
    integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script><?php /**PATH E:\xampp\htdocs\novomart.ca\resources\views/include/styles.blade.php ENDPATH**/ ?>