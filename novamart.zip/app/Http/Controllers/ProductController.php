<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;

class ProductController extends BaseController
{
    public function showProducts()
    {
    	return view('pages/product/products');
    }
    public function addToCart(Request $request)
    {
    	$quantity = $request->quantity_slct;
    	Cart::add($request->product_id, 'Product 1', $quantity, 995);

    	$request->session()->flash('msg', 'Successfully Added');
    	return redirect()->route('products');
    }
    public function delFromCart(Request $request)
    {
    	$rowId = '468399581342505c47f4615b81bedaa9';
    	$cartItem = Cart::remove($rowId);

    	return redirect()->route('add.to.cart');die;
    }
}
