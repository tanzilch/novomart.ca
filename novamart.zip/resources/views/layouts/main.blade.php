<!DOCTYPE html>
<html>
<head>
	<title>@yield('title')</title>
	@include('include.styles')
</head>
<body>
	@include('include.header')

	@yield('content')

	@include('include.footer')
	@include('include.scripts')
	@yield('customJs')
</body>
</html>