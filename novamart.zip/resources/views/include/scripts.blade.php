<script src="{{asset('public/assets/js/plugins/jquery-3.6.0.min.js')}}"></script>
<script src="{{asset('public/assets/js/plugins/bootstrap.min.js')}}"></script>